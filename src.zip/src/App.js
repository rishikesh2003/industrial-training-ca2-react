import DropDown from "./Components/DropDown/DropDown";

function App() {
  return (
    <div>
      <DropDown />
    </div>
  );
}

export default App;
